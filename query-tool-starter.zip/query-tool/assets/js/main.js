function submitQuestion() {
  const question = document.getElementById("query").value;

  fetch('process_question.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question })
  })
  .then(res => res.json())
  .then(data => {
    const resultDiv = document.getElementById("result");
    if (data.error) {
      resultDiv.innerHTML = `<div class="alert alert-danger">Error: ${data.error}</div>`;
      return;
    }

    const suggestion = data.corrected_question !== question ? 
      `<p><strong>Did you mean:</strong> "${data.corrected_question}"</p>` : '';

    const table = createTable(data.results);
    resultDiv.innerHTML = `
      ${suggestion}
      <p><strong>Generated SQL:</strong></p>
      <pre>${data.sql}</pre>
      ${table}
    `;
  });
}

function createTable(data) {
  if (!data.length) return "<p>No data found.</p>";
  let table = '<table class="table table-bordered table-striped"><thead><tr>';
  Object.keys(data[0]).forEach(key => {
    table += `<th>${key}</th>`;
  });
  table += '</tr></thead><tbody>';
  data.forEach(row => {
    table += '<tr>';
    Object.values(row).forEach(val => {
      table += `<td>${val}</td>`;
    });
    table += '</tr>';
  });
  return table + '</tbody></table>';
}
