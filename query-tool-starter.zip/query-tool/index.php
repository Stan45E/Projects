<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Data Query Assistant</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h2 class="text-center mb-4">📊 Query Your Data – Natural Language Tool</h2>

    <div class="card p-4 shadow-sm mb-4">
      <form action="upload.php" method="POST" enctype="multipart/form-data">
        <label class="form-label">Upload CSV or Excel file</label>
        <input type="file" class="form-control mb-3" name="dataset" required>
        <button type="submit" class="btn btn-primary">Upload & Parse</button>
      </form>
    </div>

    <div class="card p-4 shadow-sm mb-4">
      <label for="query" class="form-label">Ask a Question</label>
      <input type="text" id="query" class="form-control mb-3" placeholder="e.g. How many asset reallocations were made in Q1?">
      <button onclick="submitQuestion()" class="btn btn-success">Ask</button>
    </div>

    <div id="result" class="card p-4 shadow-sm"></div>
  </div>

  <script src="assets/js/main.js"></script>
</body>
</html>
