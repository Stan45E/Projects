<?php
require 'includes/db.php';
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if (isset($_FILES['dataset'])) {
    $path = "uploads/" . basename($_FILES['dataset']['name']);
    move_uploaded_file($_FILES['dataset']['tmp_name'], $path);

    $spreadsheet = IOFactory::load($path);
    $sheet = $spreadsheet->getActiveSheet()->toArray();

    $stmt = $pdo->prepare("INSERT INTO assets_data (asset_name, action_type, site, criticality, timestamp) VALUES (?, ?, ?, ?, ?)");

    for ($i = 1; $i < count($sheet); $i++) {
        $stmt->execute($sheet[$i]);
    }

    echo "Uploaded and saved! <a href='index.php'>Go back</a>";
}
?>
