<?php
require 'includes/config.php';
require 'includes/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$question = trim($data['question']);

$messages = [
  ["role" => "system", "content" => "You are a helpful assistant that converts natural language into SQL queries based on the following MySQL table schema:
Table: assets_data
Columns: id, asset_name, action_type, site, criticality, timestamp.

You should also suggest a corrected version of the user's question if it's grammatically incorrect."],
  ["role" => "user", "content" => "User's question: "$question". Provide the SQL query and corrected version if needed. Format response as: SQL Query: ... Corrected Question: ..."]
];

$ch = curl_init('https://api.openai.com/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
  "model" => "gpt-4o",
  "messages" => $messages,
  "temperature" => 0
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  'Content-Type: application/json',
  'Authorization: Bearer ' . OPENAI_API_KEY
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$content = $result['choices'][0]['message']['content'];

preg_match('/SQL Query:\s*(.*?)\s*Corrected Question:/is', $content, $matches);
$sql = trim($matches[1] ?? '');
preg_match('/Corrected Question:\s*(.*)/is', $content, $match2);
$corrected = trim($match2[1] ?? '');

$output = [];

if ($sql) {
  try {
    $res = $pdo->query($sql);
    $output['results'] = $res->fetchAll(PDO::FETCH_ASSOC);
    $output['sql'] = $sql;
    $output['corrected_question'] = $corrected ?: $question;
  } catch (Exception $e) {
    $output['error'] = "SQL Execution Error: " . $e->getMessage();
  }
} else {
  $output['error'] = "Could not generate SQL. Please try rephrasing.";
}

echo json_encode($output);
?>
